import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class screensaver extends PApplet {

float x, y, a, strokeW, pointCount, strokeR, strokeG, strokeB, pick;
public void setup() {
  background(0);
  
  x = random(width);
  y = random(height);
  a = 0;
}
public void draw() { 
  a += 1;
  strokeW = random(1, 5);
  pointCount = random(2, 30);
  strokeR = random(255);
  strokeG = random(255);
  strokeB = random(255);
  if (x > width || x < 0 || y > height || y < 0) {
    x = random(width);
    y = random(height);
    pick = PApplet.parseInt(random(4));
  }
  if (pick == 0) {  
    stroke(strokeR, strokeG, strokeB);
    strokeWeight(strokeW);
    moveRight(x, y, pointCount);
  } else if (pick == 1) {  
    stroke(strokeR, strokeG, strokeB);
    strokeWeight(strokeW);
    moveLeft(x, y, pointCount);
  } else if (pick == 2) {  
    stroke(strokeR, strokeG, strokeB);
    strokeWeight(strokeW);
    moveDown(x, y, pointCount);
  } else if (pick == 3) {  
    stroke(strokeR, strokeG, strokeB);
    strokeWeight(strokeW);
    moveUp(x, y, pointCount);
  }
  if (a > 500) {
    background(0);
    a = 0;
  }
}
public void moveRight(float startX, float startY, float moveCount) {
  for (float i = 0; i < moveCount; i++) {
    point(startX+i, startY);
    x = startX + i;
    y = startY;
  }
}
public void moveDown(float startX, float startY, float moveCount) {
  for (float i = 0; i < moveCount; i++) {
    point(startX, startY+i);
    x = startX;
    y = startY + i;
  }
}
public void moveLeft(float startX, float startY, float moveCount) {
  for (float i = 0; i < moveCount; i++) {
    point(startX - i, startY);
    x = startX - i;
    y = startY;
  }
}
public void moveUp(float startX, float startY, float moveCount) {
  for (float i = 0; i < moveCount; i++) {
    point(startX, startY-i);
    x = startX;
    y = startY-i;
  }
}
  public void settings() {  size(500, 500); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "screensaver" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
